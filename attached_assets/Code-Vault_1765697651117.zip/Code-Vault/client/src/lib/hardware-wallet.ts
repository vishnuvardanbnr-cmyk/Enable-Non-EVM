import "./polyfills";
import TransportWebHID from "@ledgerhq/hw-transport-webhid";
import Eth from "@ledgerhq/hw-app-eth";
import { ethers } from "ethers";
import { piWallet } from "./pi-wallet";

export type HardwareWalletType = "ledger" | "simulated" | "raspberry_pi" | null;
export type ConnectionStatus = "disconnected" | "connecting" | "connected" | "locked" | "unlocked";

export interface HardwareWalletState {
  type: HardwareWalletType;
  status: ConnectionStatus;
  deviceName: string | null;
  error: string | null;
}

export interface DerivedAddress {
  path: string;
  address: string;
  chainId: number;
}

const BIP44_PATHS = {
  ethereum: "44'/60'/0'/0/0",
  bitcoin: "44'/0'/0'/0/0",
};

class HardwareWalletService {
  private transport: TransportWebHID | null = null;
  private ethApp: Eth | null = null;
  private state: HardwareWalletState = {
    type: null,
    status: "disconnected",
    deviceName: null,
    error: null,
  };
  private listeners: Set<(state: HardwareWalletState) => void> = new Set();
  private simulatedSeedPhrase: string | null = null;
  private simulatedPinHash: string | null = null;
  private sessionTimeout: ReturnType<typeof setTimeout> | null = null;
  private sessionTimeoutMs: number = 5 * 60 * 1000; // 5 minutes default

  private async hashPin(pin: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(pin + "securevault-salt");
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
  }

  getState(): HardwareWalletState {
    return { ...this.state };
  }

  subscribe(listener: (state: HardwareWalletState) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private setState(updates: Partial<HardwareWalletState>) {
    this.state = { ...this.state, ...updates };
    this.listeners.forEach(listener => listener(this.getState()));
  }

  isWebHIDSupported(): boolean {
    return typeof navigator !== "undefined" && "hid" in navigator;
  }

  isWebSerialSupported(): boolean {
    return piWallet.isWebSerialSupported();
  }

  private picoHasWallet: boolean = false;

  hasWalletOnDevice(): boolean {
    return this.picoHasWallet;
  }

  setHasWalletOnDevice(hasWallet: boolean): void {
    this.picoHasWallet = hasWallet;
  }

  async connectRaspberryPi(): Promise<boolean> {
    console.log("[HardwareWallet] connectRaspberryPi() called");
    
    if (!this.isWebSerialSupported()) {
      console.log("[HardwareWallet] WebSerial not supported");
      this.setState({ 
        error: "WebSerial is not supported in this browser. Please use Chrome or Edge.",
        status: "disconnected"
      });
      return false;
    }

    try {
      this.setState({ status: "connecting", error: null });
      console.log("[HardwareWallet] Status set to 'connecting'");

      const connected = await piWallet.connect();
      console.log("[HardwareWallet] piWallet.connect() result:", connected);
      if (!connected) {
        throw new Error("Failed to connect to Raspberry Pi");
      }

      const pong = await piWallet.ping();
      console.log("[HardwareWallet] piWallet.ping() result:", pong);
      if (!pong) {
        throw new Error("Device not responding");
      }

      const status = await piWallet.getStatus();
      console.log("[HardwareWallet] piWallet.getStatus() result:", status);
      
      this.picoHasWallet = status?.has_seed === true;
      console.log("[HardwareWallet] Device has wallet:", this.picoHasWallet);
      
      this.setState({
        type: "raspberry_pi",
        status: status?.locked === false ? "unlocked" : "connected",
        deviceName: status?.device_name || "Raspberry Pi Wallet",
        error: null,
      });
      console.log("[HardwareWallet] Final state:", this.getState());

      return true;
    } catch (error: any) {
      let errorMessage = "Failed to connect to Raspberry Pi wallet";
      
      if (error.message?.includes("No device selected")) {
        errorMessage = "No device selected. Please try again.";
      } else if (error.message) {
        errorMessage = error.message;
      }

      this.setState({
        type: null,
        status: "disconnected",
        deviceName: null,
        error: errorMessage,
      });
      return false;
    }
  }

  async connectLedger(): Promise<boolean> {
    if (!this.isWebHIDSupported()) {
      this.setState({ 
        error: "WebHID is not supported in this browser. Please use Chrome, Edge, or Opera.",
        status: "disconnected"
      });
      return false;
    }

    try {
      this.setState({ status: "connecting", error: null });

      this.transport = await TransportWebHID.create() as TransportWebHID;
      this.ethApp = new Eth(this.transport as any);

      const config = await this.ethApp.getAppConfiguration();
      
      this.setState({
        type: "ledger",
        status: "connected",
        deviceName: `Ledger (Ethereum App v${config.version})`,
        error: null,
      });

      if (this.transport) {
        this.transport.on("disconnect", () => {
          this.handleDisconnect();
        });
      }

      return true;
    } catch (error: any) {
      let errorMessage = "Failed to connect to Ledger device";
      
      if (error.name === "TransportOpenUserCancelled") {
        errorMessage = "Connection cancelled by user";
      } else if (error.message?.includes("No device selected")) {
        errorMessage = "No device selected. Please try again.";
      } else if (error.statusCode === 0x6700) {
        errorMessage = "Please open the Ethereum app on your Ledger";
      } else if (error.statusCode === 0x6e00) {
        errorMessage = "App not open. Please open the Ethereum app on your Ledger";
      }

      this.setState({
        type: null,
        status: "disconnected",
        deviceName: null,
        error: errorMessage,
      });
      return false;
    }
  }

  async connectSimulated(seedPhrase: string, pin?: string): Promise<boolean> {
    try {
      this.setState({ status: "connecting", error: null });

      const words = seedPhrase.trim().split(/\s+/);
      if (words.length !== 12 && words.length !== 24) {
        throw new Error("Seed phrase must be 12 or 24 words");
      }

      try {
        ethers.Mnemonic.fromPhrase(seedPhrase);
      } catch {
        throw new Error("Invalid seed phrase");
      }

      this.simulatedSeedPhrase = seedPhrase;
      
      if (pin) {
        this.simulatedPinHash = await this.hashPin(pin);
      }

      this.setState({
        type: "simulated",
        status: "connected",
        deviceName: "Simulated Hardware Wallet",
        error: null,
      });

      return true;
    } catch (error: any) {
      this.setState({
        type: null,
        status: "disconnected",
        deviceName: null,
        error: error.message || "Failed to create simulated wallet",
      });
      return false;
    }
  }

  async setPin(pin: string): Promise<boolean> {
    if (pin.length < 4 || pin.length > 6 || !/^\d+$/.test(pin)) {
      this.setState({ error: "PIN must be 4-6 digits" });
      return false;
    }
    this.simulatedPinHash = await this.hashPin(pin);
    return true;
  }

  async unlock(pin: string): Promise<boolean> {
    if (this.state.type === "raspberry_pi") {
      try {
        await piWallet.unlock(pin);
        this.setState({ status: "unlocked" });
        this.startSessionTimeout();
        return true;
      } catch (error: any) {
        this.setState({ error: error.message || "Failed to unlock" });
        return false;
      }
    }

    if (this.state.type === "simulated") {
      if (pin.length < 4 || pin.length > 6 || !/^\d+$/.test(pin)) {
        this.setState({ error: "PIN must be 4-6 digits" });
        return false;
      }
      
      if (this.simulatedPinHash) {
        const inputHash = await this.hashPin(pin);
        if (inputHash !== this.simulatedPinHash) {
          this.setState({ error: "Incorrect PIN" });
          return false;
        }
      } else {
        this.simulatedPinHash = await this.hashPin(pin);
      }
      
      this.setState({ status: "unlocked" });
      this.startSessionTimeout();
      return true;
    }

    if (this.state.type === "ledger" && this.state.status === "connected") {
      this.setState({ status: "unlocked" });
      this.startSessionTimeout();
      return true;
    }

    return false;
  }

  async getAddress(chainId: number = 1): Promise<string | null> {
    if (this.state.status !== "unlocked") {
      this.setState({ error: "Device is locked. Please unlock first." });
      return null;
    }

    try {
      if (this.state.type === "raspberry_pi") {
        return await piWallet.getAddress(chainId);
      }

      if (this.state.type === "ledger" && this.ethApp) {
        const path = BIP44_PATHS.ethereum;
        const result = await this.ethApp.getAddress(path);
        return result.address;
      }

      if (this.state.type === "simulated" && this.simulatedSeedPhrase) {
        const mnemonic = ethers.Mnemonic.fromPhrase(this.simulatedSeedPhrase);
        const hdNode = ethers.HDNodeWallet.fromMnemonic(mnemonic, "m/44'/60'/0'/0/0");
        return hdNode.address;
      }

      return null;
    } catch (error: any) {
      this.setState({ error: error.message || "Failed to get address" });
      return null;
    }
  }

  async getMultipleAddresses(chainIds: number[]): Promise<DerivedAddress[]> {
    if (this.state.status !== "unlocked") {
      return [];
    }

    const addresses: DerivedAddress[] = [];

    try {
      if (this.state.type === "raspberry_pi") {
        const piAddresses = await piWallet.getAddresses(chainIds);
        return piAddresses.map(addr => ({
          path: addr.path,
          address: addr.address,
          chainId: addr.chainId,
        }));
      }

      if (this.state.type === "simulated" && this.simulatedSeedPhrase) {
        const mnemonic = ethers.Mnemonic.fromPhrase(this.simulatedSeedPhrase);
        
        for (const chainId of chainIds) {
          const path = "m/44'/60'/0'/0/0";
          const hdNode = ethers.HDNodeWallet.fromMnemonic(mnemonic, path);
          addresses.push({
            path,
            address: hdNode.address,
            chainId,
          });
        }
      }

      if (this.state.type === "ledger" && this.ethApp) {
        const path = BIP44_PATHS.ethereum;
        const result = await this.ethApp.getAddress(path);
        
        for (const chainId of chainIds) {
          addresses.push({
            path,
            address: result.address,
            chainId,
          });
        }
      }
    } catch (error: any) {
      this.setState({ error: error.message || "Failed to derive addresses" });
    }

    return addresses;
  }

  async signTransaction(unsignedTx: ethers.TransactionRequest): Promise<string | null> {
    if (this.state.status !== "unlocked") {
      this.setState({ error: "Device is locked" });
      return null;
    }

    try {
      if (this.state.type === "raspberry_pi") {
        return await piWallet.signTransaction({
          to: unsignedTx.to as string,
          value: unsignedTx.value?.toString() || "0",
          data: unsignedTx.data as string,
          nonce: Number(unsignedTx.nonce),
          gasLimit: unsignedTx.gasLimit?.toString() || "21000",
          gasPrice: unsignedTx.gasPrice?.toString(),
          maxFeePerGas: unsignedTx.maxFeePerGas?.toString(),
          maxPriorityFeePerGas: unsignedTx.maxPriorityFeePerGas?.toString(),
          chainId: Number(unsignedTx.chainId) || 1,
        });
      }

      if (this.state.type === "simulated" && this.simulatedSeedPhrase) {
        const mnemonic = ethers.Mnemonic.fromPhrase(this.simulatedSeedPhrase);
        const hdNode = ethers.HDNodeWallet.fromMnemonic(mnemonic, "m/44'/60'/0'/0/0");
        const signedTx = await hdNode.signTransaction(unsignedTx);
        return signedTx;
      }

      if (this.state.type === "ledger" && this.ethApp) {
        const path = BIP44_PATHS.ethereum;
        
        const baseTx: ethers.TransactionLike = {
          to: unsignedTx.to as string,
          value: unsignedTx.value,
          data: unsignedTx.data as string,
          nonce: unsignedTx.nonce,
          gasLimit: unsignedTx.gasLimit,
          gasPrice: unsignedTx.gasPrice,
          chainId: unsignedTx.chainId,
        };

        const serialized = ethers.Transaction.from(baseTx).unsignedSerialized;
        const rawTxHex = serialized.slice(2);

        const signature = await this.ethApp.signTransaction(path, rawTxHex);

        const signedTx = ethers.Transaction.from({
          ...baseTx,
          signature: {
            r: "0x" + signature.r,
            s: "0x" + signature.s,
            v: parseInt(signature.v, 16),
          },
        });

        return signedTx.serialized;
      }

      return null;
    } catch (error: any) {
      this.setState({ error: error.message || "Failed to sign transaction" });
      return null;
    }
  }

  async signMessage(message: string): Promise<string | null> {
    if (this.state.status !== "unlocked") {
      this.setState({ error: "Device is locked" });
      return null;
    }

    try {
      if (this.state.type === "raspberry_pi") {
        return await piWallet.signMessage(message);
      }

      if (this.state.type === "simulated" && this.simulatedSeedPhrase) {
        const mnemonic = ethers.Mnemonic.fromPhrase(this.simulatedSeedPhrase);
        const hdNode = ethers.HDNodeWallet.fromMnemonic(mnemonic, "m/44'/60'/0'/0/0");
        return await hdNode.signMessage(message);
      }

      if (this.state.type === "ledger" && this.ethApp) {
        const path = BIP44_PATHS.ethereum;
        const messageBuffer = Buffer.from(message);
        const signature = await this.ethApp.signPersonalMessage(path, messageBuffer as any);
        
        const vNum = typeof signature.v === 'string' ? Number.parseInt(signature.v, 16) : signature.v;
        const sig = ethers.Signature.from({
          r: "0x" + signature.r,
          s: "0x" + signature.s,
          v: vNum,
        } as any);
        return sig.serialized;
      }

      return null;
    } catch (error: any) {
      this.setState({ error: error.message || "Failed to sign message" });
      return null;
    }
  }

  private handleDisconnect() {
    this.transport = null;
    this.ethApp = null;
    this.setState({
      type: null,
      status: "disconnected",
      deviceName: null,
      error: "Device disconnected",
    });
  }

  async disconnect(): Promise<void> {
    this.clearSessionTimeout();
    if (this.state.type === "raspberry_pi") {
      await piWallet.disconnect();
    }
    if (this.transport) {
      await this.transport.close();
    }
    this.transport = null;
    this.ethApp = null;
    this.simulatedSeedPhrase = null;
    this.simulatedPinHash = null;
    this.picoHasWallet = false;
    this.setState({
      type: null,
      status: "disconnected",
      deviceName: null,
      error: null,
    });
  }

  async lock(): Promise<void> {
    if (this.state.status === "unlocked") {
      this.clearSessionTimeout();
      if (this.state.type === "raspberry_pi") {
        await piWallet.lock();
      }
      this.setState({ status: "connected" });
    }
  }

  private startSessionTimeout(): void {
    this.clearSessionTimeout();
    this.sessionTimeout = setTimeout(() => {
      if (this.state.status === "unlocked") {
        this.lock();
      }
    }, this.sessionTimeoutMs);
  }

  private clearSessionTimeout(): void {
    if (this.sessionTimeout) {
      clearTimeout(this.sessionTimeout);
      this.sessionTimeout = null;
    }
  }

  resetSessionTimeout(): void {
    if (this.state.status === "unlocked") {
      this.startSessionTimeout();
    }
  }

  setSessionTimeoutMs(ms: number): void {
    this.sessionTimeoutMs = ms;
    if (this.state.status === "unlocked") {
      this.startSessionTimeout();
    }
  }

  getSessionTimeoutMs(): number {
    return this.sessionTimeoutMs;
  }

  getSeedPhrase(): string | null {
    if (this.state.type === "simulated" && this.simulatedSeedPhrase) {
      return this.simulatedSeedPhrase;
    }
    return null;
  }

  async getSeedPhraseFromDevice(): Promise<string | null> {
    if (this.state.type === "raspberry_pi") {
      try {
        return await piWallet.getSeedPhrase();
      } catch (error) {
        console.error("Failed to get seed phrase from device:", error);
        return null;
      }
    }
    return this.getSeedPhrase();
  }
}

export const hardwareWallet = new HardwareWalletService();
